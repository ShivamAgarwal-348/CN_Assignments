file = open('queues/assignment3q3.tr')
enqueue = []
dequeue = []
difference = []
contents = file.read()
contents = contents.split('\n')
for i in range(len(contents)):
    contents[i] = contents[i].split(' ')


for i in range(len(contents)):
    if contents[i][0] == '+' : 
        enqueue += [contents[i][1]]
    if contents[i][0] == '-' : 
        dequeue += [contents[i][1]]

minlength = min(len(enqueue), len(dequeue))

for i in range(minlength):
    difference += [float(dequeue[i]) - float(enqueue[i]) ]


file2 = open('queues/qdelayq3.txt', 'w')
for i in range(minlength):
    file2.write(enqueue[i] + ' ' + dequeue[i] + ' ' + str(difference[i]) +'\n')


